package com.example.quotifiy_viewmodel_viewmodelfactory

data class Quote(val text:String,val author:String)