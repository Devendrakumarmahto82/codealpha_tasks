package com.example.quotifiy_viewmodel_viewmodelfactory

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider

class MainActivity : AppCompatActivity() {
    private lateinit var viewModel: MainViewModel

    private val quoteText:TextView
        get()=findViewById(R.id.quoteText)

    private val quoteAuthor:TextView
        get()=findViewById(R.id.quoteAuthor)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        viewModel=ViewModelProvider(this,MainViewModelFactory(application)).get(MainViewModel::class.java)
         setQuote(viewModel.getQuote())
    }

    fun setQuote(quote: Quote){
        quoteText.text=quote.text
        quoteAuthor.text=quote.author
    }

    fun onPrevious(view:View){
        setQuote(viewModel.getPreviousQuote())
    }

    fun onNext(view: View){
        setQuote(viewModel.getNextQuote())
    }

    fun onShare(view: View){
        val intent=Intent(Intent.ACTION_SEND)
        intent.setType("text/plain")
        intent.putExtra(Intent.EXTRA_TEXT,viewModel.getQuote().text)
        startActivity(intent)
    }
}